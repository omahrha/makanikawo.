fetch('data/products.json').then(r=>r.json()).then(data=>{
const c=document.getElementById('products');
const s=document.getElementById('search');
function render(list){c.innerHTML=list.slice(0,1000).map(p=>`<div class='card'><h3>${p.name}</h3><a target='_blank' href='https://wa.me/256706850769?text=Quote for ${encodeURIComponent(p.name)}'>Request Quote on WhatsApp</a></div>`).join('')}
render(data);
s.oninput=()=>render(data.filter(x=>x.name.toLowerCase().includes(s.value.toLowerCase())));
});